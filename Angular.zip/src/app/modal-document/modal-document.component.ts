import { Component, OnInit } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-modal-document',
  templateUrl: './modal-document.component.html',
  styleUrls: ['./modal-document.component.css']
})
export class ModalDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }



}
